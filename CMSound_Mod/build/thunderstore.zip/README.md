# CM Scooby Laugh Sound Mod

This mod adds in a Sooby Laugh sound effect to the game that is played everytime the player enters a new game and it replaces the Ship Intro sound.
The Scooby Laugh also has a random chance to replace 15 other sounds in the game. The sounds it replaces is randomized every time a new file is loaded.

This mod is still a work in progress and may have several bugs!

Created by Christian Marinkovich (@Christian2147 on github)

Default icon by @lilujk on github.